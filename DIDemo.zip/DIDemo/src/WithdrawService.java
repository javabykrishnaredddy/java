public class WithdrawService implements TransactionService {
    public void executeTransaction(BankAccount account, double amount) {
        account.withdraw(amount);
        System.out.println("Withdrawn INR" + amount + " from account " + account.getAccountNumber());
    }
}