public interface TransactionService {
    void executeTransaction(BankAccount account, double amount);
}