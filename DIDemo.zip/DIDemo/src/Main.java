public class Main {
    public static void main(String[] args) {
        BankAccount account = new BankAccount("12345", 1000.0);

        TransactionService depositService = new DepositService();
        TransactionService withdrawService = new WithdrawService();

        BankApplication depositApp = new BankApplication(depositService);
        BankApplication withdrawApp = new BankApplication(withdrawService);

        depositApp.performTransaction(account, 500.0);
        withdrawApp.performTransaction(account, 200.0);

        System.out.println("Final balance in account " + account.getAccountNumber() + ": INR" + account.getBalance());
    }
}