public class BankApplication {
    private TransactionService transactionService;

    public BankApplication(TransactionService transactionService) {
        this.transactionService = transactionService;
    }

    public void performTransaction(BankAccount account, double amount) {
        transactionService.executeTransaction(account, amount);
    }
}