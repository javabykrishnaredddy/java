
public class DepositService implements TransactionService {
    public void executeTransaction(BankAccount account, double amount) {
        account.deposit(amount);
        System.out.println("Deposited INR" + amount + " into account " + account.getAccountNumber());
    }
}